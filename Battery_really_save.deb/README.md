# Batery_really_save_Linux
This is an install package to save battery on Linux distribution
