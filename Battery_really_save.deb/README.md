# Batery really save Linux
This is an install package to save battery on Linux distribution.

Its include a package for Ubuntu and Debian.

If you have a NVIDIA GPU you can install the latest NVIDIA drivers version and change in PRIME Profiles to intel power saving GPU.
