# Batery really save Linux
This is an install package to save battery on Linux distribution.

Its include a package for Ubuntu and Debian
